package model;

public class ContaPoupanca extends Conta{
	
/* o	Atributos:
	taxaRendimento: double
o	Métodos:
	calcularRendimento(): double
*/
	
	private double taxaRendimento;
	
	//Getters e Setters
	//Getter e setter ---> TAXA RENDIMNTO
	public double getTaxaRendimento() {
		return taxaRendimento;
	}

	public void setTaxaRendimento(double taxaRendimento) {
		this.taxaRendimento = taxaRendimento;
	}

	
	//Métodos
	public double calcularRendimento(){
		
	}
}
