package model;

public class Relatorio {
	
	/* o	Atributos:
	tipo: String
	dataGeracao: LocalDateTime
	dados: List<String>
o	Métodos:
	gerarRelatorioGeral(): void
	exportarParaExcel(): void
*/
	
	private String tipo_relatorio;
	private LocalDateTime dataGeracao;
	private List<String> dados;
	
	public void gerarRelatorioGeral(){
		
	}
	
	public void exportarParaExcel(){
		
	}
}
