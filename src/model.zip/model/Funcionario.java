package model;

import java.time.LocalDate;

import dao.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Funcionario extends Usuario {
	
	//Declarando Atributos
	private String codigoFuncionario;
	private String cargo;
	private String senha_funcionario;
	
	
	//Construtor
	public Funcionario(int id_usuario, String nome_usuario, String cpf_usuario, LocalDate dataNascimento_usuario,
			String telefone_usuario, Endereco endereco, String codigoFuncionario, String cargo, String senha_funcionario) {
		super(id_usuario, nome_usuario, cpf_usuario, dataNascimento_usuario, telefone_usuario, endereco);
		this.codigoFuncionario = codigoFuncionario;
		this.cargo = cargo;
		this.senha_funcionario = senha_funcionario;
	}
	
	
	//Getters e Setters
	//Getter e setter ---> CODIGO FUNCIONARIO
	public String getCodigoFuncionario() {
		return codigoFuncionario;
	}
	

	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}
	
	//Getter e setter ---> CARGO
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	//Getter e setter ---> SENHA
	public String getSenha_funcionario() {
		return senha_funcionario;
	}
	
	public void setSenha_funcionario(String senha_funcionario) {
		this.senha_funcionario = senha_funcionario;
	}
	

	//Métodos
	public void abrirConta(Conta conta) {
		String sql = "INSERT INTO conta(numero_conta, agencia, saldo, tipo_conta, id_cliente) VALUES (?, ?, ?, ?, ?);";
		
		try(Connection conn = ConnectionFactory.conectar();
			PreparedStatement stmt = conn.prepareStatement(sql)) {
			
	        stmt.setInt(1, conta.numero_conta);
	        stmt.setString(2, conta.agencia_conta);
	        stmt.setDouble(3, conta.saldo_conta);
	        stmt.setString(4, conta.tipo_conta);
	        stmt.setInt(5, super.id_usuario);
	        
	        int rowsInserted = stmt.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            System.out.println("Conta criada com sucesso!");
	        }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void encerrarConta(Conta conta) {
		//LEMBRAR DE SENHA DE ADMINSITRADOR P FAZER ISSO
		String sql = "DELETE FROM conta WHERE numero_conta = ?;";
		
		try(Connection conn = ConnectionFactory.conectar();
			PreparedStatement stmt = conn.prepareStatement(sql)) {
			
	        stmt.setInt(1, conta.numero_conta);
	        
	        int rowsInserted = stmt.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            System.out.println("Conta excluída com sucesso!");
	        }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public Conta consultarDadosConta(Conta conta) {
	    String sql = "SELECT numero_conta, agencia, saldo, tipo_conta, id_cliente FROM conta WHERE numero_conta = ?;";

	    try (Connection conn = ConnectionFactory.conectar();
	            PreparedStatement stmt = conn.prepareStatement(sql)) {
	           
	           stmt.setInt(1, conta.numero_conta);
	           var rs = stmt.executeQuery();
	           
	           if (rs.next()) {
	               
	               conta.numero_conta = rs.getInt("numero_conta");
	               conta.agencia_conta = rs.getString("agencia");
	               conta.saldo_conta = rs.getDouble("saldo");
	               conta.tipo_conta = rs.getString("tipo_conta");
	               super.id_usuario = rs.getInt("id_cliente");
	               return conta;
	           } else {
	               System.out.println("Conta não encontrada.");
	               return null;
	           }
	       } catch (SQLException sqle) {
	           sqle.printStackTrace();
	           return null;
	       }
	}
	
	public Cliente consultarDadosCliente(Cliente cliente) {
	    String sql = "SELECT u.id_usuario, u.nome AS nome_usuario, u.cpf AS cpf_usuario, u.data_nascimento, u.telefone" +
	                 "u.senha, e.cep, e.local, e.numero_casa, e.bairro, e.cidade, e.estado FROM usuario" +
	                 "u JOIN endereco e ON u.id_usuario = e.id_usuario WHERE u.id_usuario = ?;";

	    try (Connection conn = ConnectionFactory.conectar();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {
	        
	        stmt.setInt(1, id_usuario);
	        var rs = stmt.executeQuery();
	        
	        if (rs.next()) {

	        		// Criando o objeto Cliente com os dados obtidos   
	            	super.id_usuario = rs.getInt("id_cliente");
	            	cliente.nome_usuario = rs.getString("nome_usuario");
	            	cliente.cpf_usuario = rs.getString("cpf_usuario");
	            	cliente.dataNascimento_usuario = rs.getObject("data_nascimento", LocalDate.class);
	            	cliente.telefone_usuario = rs.getString("telefone");
	            	cliente.setSenha(rs.getString("senha"));
	            	
	            	// Criando o objeto Endereco com os dados obtidos
		            Endereco endereco = new Endereco();
		            endereco.setCep(rs.getString("cep"));
		            endereco.setLocal(rs.getString("local"));
		            endereco.setNumeroCasa(rs.getInt("numero_casa"));
		            endereco.setBairro(rs.getString("bairro"));
		            endereco.setCidade(rs.getString("cidade"));
		            endereco.setEstado(rs.getString("estado"));
		            
		            cliente.endereco = endereco;
	            
	            return cliente;
	        } else {
	            System.out.println("Cliente não encontrado.");
	            return null;
	        }
	    } catch (SQLException sqle) {
	        sqle.printStackTrace();
	        return null;
	    }
	}


	public void alterarDadosConta(Conta conta) {
		String sql = "ALTER TABLE ";
		
	}
	
	public void alterarDadosCliente(Cliente cliente) {
		
	}
	
	public void cadastrarFuncionario(Funcionario funcionario){
		
	}
	
	public void gerarRelatorioMovimentacao() {
		
	}
	
	
}
